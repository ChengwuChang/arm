# [Niapy](https://github.com/NiaOrg/NiaPy)

## Start 

* Run `main.py`
